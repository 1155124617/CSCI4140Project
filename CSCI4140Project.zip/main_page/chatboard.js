

(function ($) {
    "use strict";
    /*==================================================================
    [ Validate ]*/



    window.onload=function(){
        if($.cookie("username")===undefined)
        {
            alert("You already logout, please log in first!");
            window.location.replace("../sign_in/index.html");
        }
        else
            $("#helloUser").text("hello, "+$.cookie("username")+" !  ");
        
        $('#logout').click(function(){
            $.removeCookie("username", {path:'/'});
        });
        
        $.ajax({
          url: "comments.txt",
          type: "GET" })
          .done(function(txt){
            $("#comments").html(txt);
          });
        
    };
    
    
    
    
})(jQuery);


function processForm2(current1){

   let $new = $("<ul><li><svg><circle></circle></svg><div><h5></h5><h6></h6><p></p><table></table><div><small><a href=\"#/\" onclick=\"reply(this)\">Reply</a></small></div></div></li></ul>");
   $new.addClass("media-list");
   $new.find("li").addClass("media");
   $new.find("p").html(current1.previousSibling.elements[2].value);
   var comment = current1.previousSibling.elements[2].value;
   $new.find("div").addClass("media-body");
   $new.find("h5").html(current1.previousSibling.elements[1].value);
   var subject = current1.previousSibling.elements[1].value;
   $new.find("h6").html(current1.previousSibling.elements[0].value);
   var username = current1.previousSibling.elements[0].value;
   //bonus question
   let d = new Date();
   let timeString = d.yyyymmdd();
   console.log(timeString);
   $new.find("table").html('<tr><td>Browser:</td><td>'+navigator.appName+","+navigator.appCodeName+'</td></tr>');
   $new.find("table").append('<tr><td>Time:</td><td>'+d+'</td></tr>');
   $new.find("table").append('<tr><td>IP:</td><td>'+returnCitySN["cip"]+'</td></tr>');
   $new.find("table").append('<tr><td>Location:</td><td>'+returnCitySN["cname"]+'</td></tr>');

   $new.find("svg").attr({
     "height": 100,
     "width": 100
   })

   $new.find("circle").attr({
     "cx": 50,
     "cy": 50,
     "r": 40,
     "fill": $("input[name='inputcolor']:checked").val()
   })

   $.ajax({
     type:'HEAD',
     url: window.location.href,
     complete:function(xhr,data){
       $new.find("table").append('<tr><td>Get From Server:</td></tr><tr><td>Server Content Type:</td><td>'+xhr.getResponseHeader("Content-Type")+'</td></tr><tr><td>Content Length:</td><td>'+xhr.getResponseHeader("Content-Length")+'</td></tr>');
     }
   });

   $(current1.parentNode.parentNode.parentNode).append($new)
   current1.parentNode.innerHTML="";

    $.ajax({
       type: "POST",
       url: "/main_page/comments.txt",
    data: {data: document.getElementById("comments").innerHTML},
    success:(function(txt){alert(txt);})
     });

     console.log("first success");
     
     $.ajax({
      url: "/main_page/commentsupload",
      type: "POST",
      data: {
        comment: comment,
        subject: subject,
        username: username,
        time: timeString
      },
      success: (function(res){
        console.log(res);
      })
    });
    console.log("second success");

}


function processForm1(){
   let $new = $("<li><svg><circle></circle></svg><div><h5></h5><h6></h6><p></p><table></table><div><small><a href=\"#/\" onclick=\"reply(this)\">Reply</a></small></div></div></li>");
   $new.addClass("media");

   $new.find("p").html($("#inputcomment").val());
   $new.find("div").addClass("media-body");
   var comment = $("#inputcomment").val();
   $new.find("h5").html($("#inputsubject").val());
   var subject = $("#inputsubject").val();
   $new.find("h6").html($("#inputname").val());
   var username = $("#inputname").val();
   //bonus question
   let d = new Date();
   let timeString = d.yyyymmdd();
   console.log(timeString);
   $new.find("table").html('<tr><td>Browser:</td><td>'+navigator.appName+","+navigator.appCodeName+'</td></tr>');
   $new.find("table").append('<tr><td>Time:</td><td>'+d+'</td></tr>');
   $new.find("table").append('<tr><td>IP:</td><td>'+returnCitySN["cip"]+'</td></tr>');
   $new.find("table").append('<tr><td>Location:</td><td>'+returnCitySN["cname"]+'</td></tr>');

   $new.find("svg").attr({
     "height": 100,
     "width": 100
   })

   $new.find("circle").attr({
     "cx": 50,
     "cy": 50,
     "r": 40,
     "fill": $("input[name='inputcolor']:checked").val()
   })

   $.ajax({
     type:'HEAD',
     url: window.location.href,
     complete:function(xhr,data){
       $new.find("table").append('<tr><td>Get From Server:</td></tr><tr><td>Content Type:</td><td>'+xhr.getResponseHeader("Content-Type")+'</td></tr><tr><td>Content Length:</td><td>'+xhr.getResponseHeader("Content-Length")+'</td></tr>');
     }
   });

   $("#comments").append($new)
   $("form").trigger("reset");

    $.ajax({
      url: "/main_page/comments.txt",
      type: "POST",
      data: {data: document.getElementById("comments").innerHTML},
      success:(function(txt){alert(txt);})
    });
    console.log("First ajax success");
    $.ajax({
      url: "/main_page/commentsupload",
      type: "POST",
      data: {
        comment: comment,
        subject: subject,
        username: username,
        time: timeString
      },
      success: (function(res){
        console.log(res);
      })
    });
    console.log("Second success");




}

function reply(current2){
  let formCode="<div><form><div class=\"form-group\"><label for=\"inputname\">Name</label><input type=\"text\" class=\"form-control\"  name=\"name\"><label for=\"inputsubject\">Subject</label><input type=\"text\" class=\"form-control\"name=\"subject\"><label for=\"inputcomment\">Your comment</label><textarea class=\"form-control\" rows=\"5\"name=\"comment\"></textarea></div><div class=\"form-check\"><label class=\"form-check-label\"><input type=\"radio\" class=\"form-check-input\" name=\"inputcolor\" value=\"red\">Red</label></div><div class=\"form-check\"><label class=\"form-check-label\"><input type=\"radio\" class=\"form-check-input\" name=\"inputcolor\" value=\"green\">Green</label></div><div class=\"form-check\"><label class=\"form-check-label\"><input type=\"radio\" class=\"form-check-input\" name=\"inputcolor\" value=\"yellow\">Yellow</label></div><div class=\"form-check\"><label class=\"form-check-label\"><input type=\"radio\" class=\"form-check-input\" name=\"inputcolor\" value=\"blue\">Blue</label></div></form><button class=\"btn btn-primary\"  onclick=\"processForm2(this)\">Add comment</button></div>"
  $(current2.parentNode.parentNode).append(formCode)

}

Date.prototype.yyyymmdd = function() {
  var mm = this.getMonth() + 1; // getMonth() is zero-based
  var dd = this.getDate();
  var hh = this.getHours();
  var MM = this.getMinutes();

  return [this.getFullYear(),'-',
          (mm>9 ? '' : '0') + mm,'-',
          (dd>9 ? '' : '0') + dd,' ',
          (hh > 9 ? '' : '0') + hh, ':',
          (MM > 9 ? '' : '0') + MM
         ].join('');
};  

